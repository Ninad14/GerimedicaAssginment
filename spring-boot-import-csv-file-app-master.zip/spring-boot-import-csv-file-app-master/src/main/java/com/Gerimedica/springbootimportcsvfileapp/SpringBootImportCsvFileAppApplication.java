package com.Gerimedica.springbootimportcsvfileapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootImportCsvFileAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootImportCsvFileAppApplication.class, args);
	}

}
