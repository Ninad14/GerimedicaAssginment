package com.Gerimedica.springbootimportcsvfileapp;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.csv.QuoteMode;
import org.springframework.web.multipart.MultipartFile;


public class CSVHelper {
    public static String TYPE = "text/csv";

    public static boolean hasCSVFormat(MultipartFile file) {
        System.out.println(file.getContentType());
        if (TYPE.equals(file.getContentType())
                || file.getContentType().equals("application/vnd.ms-excel")) {
            return true;
        }

        return false;
    }

    public static List<GerimedicaAssignment> csvToTutorials(InputStream is) {
        try (BufferedReader fileReader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
             CSVParser csvParser = new CSVParser(fileReader,
                     CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());) {

            List<GerimedicaAssignment> gerimedicaAssignmentList = new ArrayList<>();

            Iterable<CSVRecord> csvRecords = csvParser.getRecords();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d-M-y", Locale.ENGLISH);

            for (CSVRecord csvRecord : csvRecords) {

                GerimedicaAssignment gerimedicaAssignment = new GerimedicaAssignment(
                        csvRecord.get("source"),
                        csvRecord.get("codeListCode"),
                        csvRecord.get("code"),
                        csvRecord.get("displayValue"),
                        csvRecord.get("longDescription"),
                        csvRecord.get("fromDate").isEmpty() ?  LocalDate.parse("1-1-9999", formatter) : LocalDate.parse(csvRecord.get("fromDate"), formatter),
                        csvRecord.get("toDate").isEmpty() ?  LocalDate.parse("1-1-9999", formatter) : LocalDate.parse(csvRecord.get("toDate"), formatter),
                        csvRecord.get("sortingPriority").isEmpty() ? 0 :  Integer.parseInt(csvRecord.get("sortingPriority"))
                );

                gerimedicaAssignmentList.add(gerimedicaAssignment);
            }

            return gerimedicaAssignmentList;
        } catch (IOException e) {
            throw new RuntimeException("fail to parse CSV file: " + e.getMessage());
        }
    }

    public static ByteArrayInputStream tutorialsToCSV(List<GerimedicaAssignment> gerimedicaAssignmentList) {
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);

        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
             CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {
            for (GerimedicaAssignment gerimedicaAssignment : gerimedicaAssignmentList) {
                List<String> data = Arrays.asList(
                        String.valueOf(gerimedicaAssignment.getId()),
                        gerimedicaAssignment.getSource(),
                        gerimedicaAssignment.getCodeListCode(),
                        gerimedicaAssignment.getCode(),
                        gerimedicaAssignment.getDisplayValue(),
                        gerimedicaAssignment.getLongDescription(),
                        gerimedicaAssignment.getFromDate().toString(),
                        gerimedicaAssignment.getToDate().toString(),
                        String.valueOf(gerimedicaAssignment.getSortingPriority())
                );

                csvPrinter.printRecord(data);
            }

            csvPrinter.flush();
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            throw new RuntimeException("fail to import data to CSV file: " + e.getMessage());
        }
    }
}
